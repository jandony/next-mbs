export default async function ExtraPage() {

    return <h1 className="text-5xl">Extra Page!</h1>

}